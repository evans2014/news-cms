@extends('layouts.app')
@section('title', $news->title . ' - News CMS')
@section('content')
    <div class="container py-5">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <article class="card border-0 shadow-sm">
                    @if($news->image)
                        <img src="{{ asset('storage/' . $news->image) }}" class="card-img-top" alt="{{ $news->title }}" style="max-height: 400px; object-fit: cover;">
                    @endif
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <span class="badge bg-primary fs-6">{{ $news->category->name }}</span>
                            <small class="text-muted">{{ $news->created_at->format('d.m.Y') }}</small>
                        </div>
                        <h1 class="card-title display-5 mb-4">{{ $news->title }}</h1>
                        <div class="lead">{!! nl2br(e($news->description)) !!}</div>
                    </div>
                    <div class="card-footer bg-white border-0 p-4">
                        <a href="{{ url()->previous() }}" class="btn btn-outline-secondary">
                            ← Назад
                        </a>
                    </div>
                </article>
            </div>
        </div>
    </div>
@endsection
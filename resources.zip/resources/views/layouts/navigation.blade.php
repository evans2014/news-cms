<nav class="navbar navbar-expand-lg bg-white shadow-sm">
    <div class="container">
        <!-- ЛОГО -->
        <a class="navbar-brand fw-bold text-primary" href="{{ route('home') }}">
            News CMS
        </a>

        <!-- ТОГЪЛ ЗА МОБИЛНИ -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- МЕНЮ + ВХОД/ИЗХОД -->
        <div class="collapse1 navbar-collapse" id="navbarNav">
            <!-- ГЛАВНО МЕНЮ -->
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                @php
                    $menuItems = \App\Models\MenuItem::with('children')
                                                     ->whereNull('parent_id')
                                                     ->where('is_active', true)
                                                     ->orderBy('order')
                                                     ->get();
                @endphp

                @foreach($menuItems as $item)
                    @if($item->children->count() > 0)
                        <!-- ДРОПДАУН -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                {{ $item->title }}
                            </a>
                            <ul class="dropdown-menu">
                                @foreach($item->children as $child)
                                    @php
                                        $url = $child->type === 'external' && $child->url
                                            ? $child->url
                                            : ($child->target_id
                                                ? match($child->type) {
                                                    'page'     => $child->target?->slug ? route('page.show', $child->target->slug) : '#',
                                                    'news'     => route('news.show', $child->target_id),
                                                    'category' => $child->target?->slug ? route('category.show', $child->target->slug) : '#',
                                                    default    => '#',
                                                }
                                                : '#');
                                    @endphp
                                    <li><a class="dropdown-item" href="{{ $url }}">{{ $child->title }}</a></li>
                                @endforeach
                            </ul>
                        </li>
                    @else
                        <!-- ОБИКНОВЕН ЛИНК -->
                        @php
                            $url = $item->type === 'external' && $item->url
                                ? $item->url
                                : ($item->target_id
                                    ? match($item->type) {
                                        'page'     => $item->target?->slug ? route('page.show', $item->target->slug) : '#',
                                        'news'     => route('news.show', $item->target_id),
                                        'category' => $item->target?->slug ? route('category.show', $item->target->slug) : '#',
                                        default    => '#',
                                    }
                                    : '#');
                        @endphp
                        <li class="nav-item">
                            <a class="nav-link" href="{{ $url }}">{{ $item->title }}</a>
                        </li>
                    @endif
                @endforeach
            </ul>

            <!-- ДЯСНО МЕНЮ (ВХОД/ИЗХОД) -->
            <ul class="navbar-nav">
                @auth
                    @if(auth()->user()->is_admin)
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                Админ
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="{{ route('admin.dashboard') }}">Панел</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <form method="POST" action="{{ route('logout') }}" class="d-inline">
                                        @csrf
                                        <button class="dropdown-item text-danger">Изход</button>
                                    </form>
                                </li>
                            </ul>
                        </li>
                    @else
                        <li class="nav-item">
                            <form method="POST" action="{{ route('logout') }}" class="d-inline">
                                @csrf
                                <button class="nav-link btn btn-link p-0">Изход</button>
                            </form>
                        </li>
                    @endif
                @else
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('login') }}">Вход</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('register') }}">Регистрация</a>
                    </li>
                @endauth
            </ul>
        </div>
    </div>
</nav>
@extends('layouts.admin')

@section('content')
   <!--  <div class="container mt-4">
        <h1>Редактирай категория</h1>
        <form action="{{ route('admin.categories.update', $category) }}" method="POST" enctype="multipart/form-data">
            @csrf @method('PUT')
            <div class="mb-3">
                <label>Име</label>
                <input type="text" name="name" class="form-control" value="{{ $category->name }}">
            </div>
            <div class="mb-3">
                @if($category->image)
                    <img src="{{ asset('storage/' . $category->image) }}" width="100" class="mb-2"><br>
                @endif
                <label>Ново изображение</label>
                <input type="file" name="image" class="form-control">
            </div>
            <button type="submit" class="btn btn-success">Обнови</button>
        </form>
    </div> -->
   <div class="mb-4">
       <label class="form-label fw-bold">Категории <span class="text-danger">*</span></label>
       <div class="row">
           @foreach(\App\Models\Category::orderBy('name')->get() as $category)
               <div class="col-md-4 mb-2">
                   <div class="form-check">
                       <input class="form-check-input"
                              type="checkbox"
                              name="categories[]"
                              value="{{ $category->id }}"
                              id="cat-{{ $category->id }}"
                               {{ isset($news) && $news->categories->contains($category->id) ? 'checked' : '' }}>
                       <label class="form-check-label" for="cat-{{ $category->id }}">
                           {{ $category->name }}
                       </label>
                   </div>
               </div>
           @endforeach
       </div>
       @error('categories')
       <div class="text-danger small">{{ $message }}</div>
       @enderror
   </div>
@endsection
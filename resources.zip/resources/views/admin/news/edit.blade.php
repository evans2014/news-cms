@extends('layouts.admin')

@section('content')
    <div class="container mt-4">
        <h1>Редактирай новина</h1>

        <form action="{{ route('admin.news.update', $news) }}" method="POST" enctype="multipart/form-data">
            @csrf @method('PUT')
            <div class="mb-3">
                <label class="form-label">Заглавие</label>
                <input type="text" name="title" class="form-control" value="{{ old('title', $news->title) }}">
            </div>

            <div class="mb-3">
                <label class="form-label">Описание</label>
                <textarea name="description" rows="5" class="form-control">{{ old('description', $news->description) }}</textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">Текущо изображение</label><br>
                <img src="{{ asset('storage/' . $news->image) }}" width="200" class="mb-2">
                <input type="file" name="image" class="form-control">
                <small class="text-muted">Остави празно, за да запазиш текущото.</small>
            </div>

            <div class="mb-3">
                <label class="form-label">Категория</label>
                <select name="category_id" class="form-control">
                    @foreach($categories as $cat)
                        <option value="{{ $cat->id }}" {{ $news->category_id == $cat->id ? 'selected' : '' }}>{{ $cat->name }}</option>
                    @endforeach
                </select>
            </div>

            <button type="submit" class="btn btn-success">Обнови</button>
            <a href="{{ route('admin.news.index') }}" class="btn btn-secondary">Назад</a>
        </form>
    </div>
@endsection
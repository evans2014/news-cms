@extends('layouts.admin')

@section('content')
    <div class="container mt-4">
        <h1>Добави елемент в менюто</h1>
        <form action="{{ route('admin.menu.store') }}" method="POST">
            @csrf
            <div class="mb-3">
                <label>Заглавие</label>
                <input type="text" name="title" class="form-control" required>
            </div>

            <div class="mb-3">
                <label>Тип</label>
                <select name="type" class="form-control" id="type-select" required>
                    <option value="page">Страница</option>
                    <option value="news">Новина</option>
                    <option value="category">Категория</option>
                    <option value="external">Външен линк</option>
                </select>
            </div>

            <div class="mb-3" id="target-select" style="display:none;">
                <label id="target-label">Избери</label>
                <select name="target_id" class="form-control">
                    <!-- JS ще попълни -->
                </select>
            </div>

            <div class="mb-3" id="url-input" style="display:none;">
                <label>URL</label>
                <input type="url" name="url" class="form-control" placeholder="https://example.com">
            </div>

            <button type="submit" class="btn btn-success">Добави</button>
        </form>
    </div>

    <script>
      document.getElementById('type-select').addEventListener('change', function() {
        const type = this.value;
        document.getElementById('target-select').style.display = type !== 'external' ? 'block' : 'none';
        document.getElementById('url-input').style.display = type === 'external' ? 'block' : 'none';

        if (type !== 'external') {
          const options = @json([
            'page' => $pages,
            'news' => $news,
            'category' => $categories
        ]);
          const select = document.querySelector('#target-select select');
          select.innerHTML = '';
          Object.entries(options[type]).forEach(([id, title]) => {
            select.innerHTML += `<option value="${id}">${title}</option>`;
          });
        }
      });
    </script>
@endsection
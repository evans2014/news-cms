@extends('layouts.app')

@section('title', 'Категории')

@section('content')
<div class="container py-5">
    <h1 class="display-5 mb-5 text-center">Категории</h1>

    <!-- ТЪРСАЧКА -->
    <div class="row mb-4">
        <div class="col-md-6 mx-auto">
            <input type="text" id="search-input" class="form-control form-control-lg" placeholder="Търси категория..." autocomplete="off">
        </div>
    </div>

    <!-- GRID -->
    <div id="categories-grid" class="row g-4">
        @include('partials.categories-grid', ['categories' => $categories])
    </div>

    <!-- PAGINATION -->
    <div id="pagination" class="d-flex justify-content-center mt-5">
        {{ $categories->links('partials.pagination') }}
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const grid = document.getElementById('categories-grid');
    const pagination = document.getElementById('pagination');
    const searchInput = document.getElementById('search-input');
    let timeout;

    function loadCategories(search = '') {
        const url = search 
            ? `{{ route('categories.search') }}?search=${encodeURIComponent(search)}`
            : `{{ route('categories.index') }}`;

        fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(r => r.json())
            .then(data => {
                grid.innerHTML = data.html;
                pagination.innerHTML = data.pagination;
            });
    }

    searchInput.addEventListener('input', function () {
        clearTimeout(timeout);
        timeout = setTimeout(() => loadCategories(this.value), 300);
    });

    // Пагинация с AJAX
    document.addEventListener('click', function (e) {
        if (e.target.closest('.pagination a')) {
            e.preventDefault();
            const url = e.target.closest('a').href;
            fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(r => r.json())
                .then(data => {
                    grid.innerHTML = data.html;
                    pagination.innerHTML = data.pagination;
                    window.history.pushState({}, '', url);
                });
        }
    });
});
</script>
@endsection
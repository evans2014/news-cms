@if(!isset($item) || !$item)
    @continue
@endif

@php
    $url = '#';

    if ($item->type === 'external' && $item->url) {
        $url = $item->url;
    } elseif ($item->target_id) {
        try {
            $target = match($item->type) {
                'page'     => \App\Models\Page::find($item->target_id),
                'news'     => \App\Models\News::find($item->target_id),
                'category' => \App\Models\Category::find($item->target_id),
                default    => null,
            };

            if ($target) {
                $url = match($item->type) {
                    'page'     => $target->slug ? route('page.show', $target->slug) : '#',
                    'news'     => route('news.show', $item->target_id),
                    'category' => $target->slug ? route('category.show', $target->slug) : '#',
                    default    => '#',
                };
            }
        } catch (\Exception $e) {
            $url = '#';
        }
    }
@endphp

@if($item->children && $item->children->count() > 0)
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
            {{ $item->title }}
        </a>
        <ul class="dropdown-menu">
            @foreach($item->children as $child)
                @if($child)
                    @include('partials.menu-item', ['item' => $child])
                @endif
            @endforeach
        </ul>
    </li>
@else
    <li class="nav-item">
        <a class="nav-link" href="{{ $url }}">{{ $item->title }}</a>
    </li>
@endif
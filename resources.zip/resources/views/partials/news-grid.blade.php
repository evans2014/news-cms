
 @forelse($news as $item)
     <div class="col-md-4 mb-4">
         <div class="card h-100 shadow-sm">
             @if($item->image)
                 <img src="{{ asset('storage/' . $item->image) }}" class="card-img-top" style="height:200px;object-fit:cover;" alt="{{ $item->title }}">
             @endif
             <div class="card-body d-flex flex-column">
                 <h5 class="card-title">
                     <a href="{{ route('news.show', $item->id) }}" class="text-decoration-none">
                         {{ Str::limit($item->title, 60) }}
                     </a>
                 </h5>
                 <p class="badge bg-primary mb-2">
                     {{ $item->created_at->format('d.m.Y') }}
                     @if($item->categories->count())
                         • {{ $item->categories->pluck('name')->implode(', ') }}
                     @endif
                 </p>
             </div>
         </div>
     </div>
 @empty
     <div class="col-12 text-center py-5">
         <p class="text-muted">Няма намерени новини.</p>
     </div>
 @endforelse

